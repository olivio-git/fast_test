export type ThemeEntity = "light" | "dark";
